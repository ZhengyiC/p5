README

Course: cs400
Semester: Spring 2019
Project name: MyFirstJavaFX
author: Zhengyi Chen

Notes or comments to the grader:

[place any comments or notes that will help the grader here]
